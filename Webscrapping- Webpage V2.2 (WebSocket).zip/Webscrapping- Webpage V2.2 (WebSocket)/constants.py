# constants.py
SCRIPTS_DIRECTORY = "/Users/g6-media/Webscrapping-Git/Webscrapping- Webpage/Scrapping Scripts"